﻿function valdemovalues(demovalue) {


    if (demovalue.length < 3 || (demovalue.length > 3 && demovalue.indexOf("(") < 1)) {
        return "";

    }
    else {
        return demovalue;
    }

}

function valcarValidator() {

    var Name = document.getElementById('External_CarSearch_PickUpLocation').value;
    //var tempcode = Name.substr(1, 3);
    Name = valdemovalues(Name);
    if (Name.length > 3) {
        var tempcode = Name.substring(Name.length - 4, Name.length - 1);
        document.getElementById('External_CarSearch_PickUpLocation').value = tempcode;
    }

    var Name2 = document.getElementById('External_CarSearch_DropOffLocation').value;
    //var tempcode = Name.substr(1, 3);
    Name2 = valdemovalues(Name2);
    if (Name2.length > 3) {
        var tempcode1 = Name2.substring(Name2.length - 4, Name2.length - 1);
        document.getElementById('External_CarSearch_DropOffLocation').value = tempcode1;
    }


    
}
function validatecarFormOnSubmit() {
    var Name1 = document.getElementById('External_CarSearch_PickUpLocation').value;
    //var tempcode1 = Name.substr(1, 3);
    var tempcode1 = Name1.substring(Name1.length - 3);


    var dptdate = document.getElementById('External_CarSearch_PickupDate').value;
    var rtndate = document.getElementById('External_CarSearch_DropOffDate').value;


    document.getElementById('External_CarSearch_PickUpLocation').style.border = '';

    document.getElementById('External_CarSearch_DropOffDate').style.border = '';

    document.getElementById('External_CarSearch_PickupDate').style.border = '';

    document.getElementById('External_CarSearch_DropOffLocation').style.border = '';


    if (tempcode1 == "") {
        alert("You must select Pick Up Location");
        document.getElementById('External_CarSearch_PickUpLocation').style.border = '1px solid red';
        document.getElementById('External_CarSearch_PickUpLocation').focus();
        return false;

    }

    else if (dptdate == "") {
        alert("You must select Pick Up Date");
        document.getElementById('External_CarSearch_PickupDate').style.border = '1px solid red';
        return false;

    }
    else if (rtndate == "") {
        alert("You must select Drop Off Date");
        document.getElementById('External_CarSearch_DropOffDate').style.border = '1px solid red';

        return false;
    }
    else {
        valcarValidator();
        return true;
    }

}

function valhotelValidator() {


    var Name = document.getElementById('External_HotelSearch_City').value;
    //var tempcode = Name.substr(1, 3);
    Name = valdemovalues(Name);
    if (Name.length > 3) {
        var tempcode = Name.substring(Name.length - 4, Name.length - 1);
        document.getElementById('External_HotelSearch_City').value = tempcode;
    }
    

    



}
function validatehotelFormOnSubmit() {
   
    valhotelValidator();
    var Name = document.getElementById('External_HotelSearch_City').value;
    //var tempcode = Name.substr(1, 3);
    var tempcode = document.getElementById('External_HotelSearch_City').value;

    var dptdate = document.getElementById('External_HotelSearch_CheckInDate').value;
    var rtndate = document.getElementById('External_HotelSearch_CheckOutDate').value;

    document.getElementById('External_HotelSearch_City').style.border = '';
    document.getElementById('External_HotelSearch_CheckInDate').style.border = '';
    document.getElementById('External_HotelSearch_CheckOutDate').style.border = '';


    if (tempcode == "") {
        alert("You must select City");
        document.getElementById('External_HotelSearch_City').style.border = '1px solid red';
        document.getElementById('External_HotelSearch_City').focus();
        return false;
    }
    else if (dptdate == "") {
        alert("You must select Check In Date");
        document.getElementById('External_HotelSearch_CheckInDate').style.border = '1px solid red';
        return false;
    }
    else if (rtndate == "") {
        alert("You must select Check Out Date");
        document.getElementById('External_HotelSearch_CheckOutDate').style.border = '1px solid red';
        return false;
    }
    else {
        valhotelValidator();
        return true;
    }

}



function getCode(id) {
    var Name = document.getElementById(id).value;
    Name = valdemovalues(Name);
    if (Name.length > 3) {
        var tempcodel2 = Name.substring(Name.length - 5, Name.length - 2);
        document.getElementById(id).value = tempcodel2;
    }
}

function valflightValidator() {
    //return; //For new ajax listing, it's giving wrong value.          
    getCode('External_FlightFareSearch_From'); getCode('External_FlightFareSearch_To');
	getCode('External_FlightFareSearch_From0'); getCode('External_FlightFareSearch_To0');
	getCode('External_FlightFareSearch_From1'); getCode('External_FlightFareSearch_To1');
	getCode('External_FlightFareSearch_From2'); getCode('External_FlightFareSearch_To2');
	getCode('External_FlightFareSearch_From3'); getCode('External_FlightFareSearch_To3');
	getCode('External_FlightFareSearch_From4'); getCode('External_FlightFareSearch_To4');
}

function validateFormOnSubmit() {
    valflightValidator();
   
    var Name = document.getElementById('External_FlightFareSearch_To').value;
    var tempcode = Name.substring(Name.length - 3);
    var Name1 = document.getElementById('External_FlightFareSearch_From').value;
    var tempcode1 = Name1.substring(Name1.length - 3);
	
	var Name2 = document.getElementById('External_FlightFareSearch_To0').value;
    var tempcode2 = Name2.substring(Name2.length - 3);
    var Name3 = document.getElementById('External_FlightFareSearch_From0').value;
    var tempcode3 = Name3.substring(Name3.length - 3);
	
	var Name4 = document.getElementById('External_FlightFareSearch_To1').value;
    var tempcode4 = Name4.substring(Name4.length - 3);
    var Name5 = document.getElementById('External_FlightFareSearch_From1').value;
    var tempcode5 = Name5.substring(Name5.length - 3);
	
	var Name6 = document.getElementById('External_FlightFareSearch_To2').value;
    var tempcode6 = Name6.substring(Name6.length - 3);
    var Name7 = document.getElementById('External_FlightFareSearch_From2').value;
    var tempcode7 = Name7.substring(Name7.length - 3);
	
	
	var Name8 = document.getElementById('External_FlightFareSearch_To3').value;
    var tempcode8 = Name8.substring(Name8.length - 3);
    var Name9 = document.getElementById('External_FlightFareSearch_From3').value;
    var tempcode9 = Name9.substring(Name9.length - 3);
	
	var Name10 = document.getElementById('External_FlightFareSearch_To4').value;
    var tempcode10 = Name10.substring(Name10.length - 3);
    var Name11 = document.getElementById('External_FlightFareSearch_From4').value;
    var tempcode11 = Name11.substring(Name11.length - 3);
	
	

    var dptdate = document.getElementById('External_FlightFareSearch_DepartureDate').value;
    var rtndate = document.getElementById('External_FlightFareSearch_ReturnDate').value;

   
    var dptdate0 = document.getElementById('External_FlightFareSearch_DepartureDate0').value;
    var rtndate0 = document.getElementById('External_FlightFareSearch_ReturnDate0').value;
	
	
	var dptdate1 = document.getElementById('External_FlightFareSearch_DepartureDate1').value;
    var rtndate1= document.getElementById('External_FlightFareSearch_ReturnDate1').value;
	
	
	var dptdate2 = document.getElementById('External_FlightFareSearch_DepartureDate2').value;
    var rtndate2 = document.getElementById('External_FlightFareSearch_ReturnDate2').value;
   
    var dptdate3 = document.getElementById('External_FlightFareSearch_DepartureDate3').value;
    var rtndate3 = document.getElementById('External_FlightFareSearch_ReturnDate3').value;
	
	var dptdate4 = document.getElementById('External_FlightFareSearch_DepartureDate4').value;
    var rtndate4 = document.getElementById('External_FlightFareSearch_ReturnDate4').value;
   
   
    document.getElementById('External_FlightFareSearch_DepartureDate').style.border = '';
    document.getElementById('External_FlightFareSearch_ReturnDate').style.border = '';
	
    document.getElementById('External_FlightFareSearch_DepartureDate0').style.border = '';
    document.getElementById('External_FlightFareSearch_ReturnDate0').style.border = '';
	
    document.getElementById('External_FlightFareSearch_DepartureDate1').style.border = '';
    document.getElementById('External_FlightFareSearch_ReturnDate1').style.border = '';
	
    document.getElementById('External_FlightFareSearch_DepartureDate2').style.border = '';
    document.getElementById('External_FlightFareSearch_ReturnDate2').style.border = '';
   
    document.getElementById('External_FlightFareSearch_DepartureDate3').style.border = '';
    document.getElementById('External_FlightFareSearch_ReturnDate3').style.border = '';
	
	document.getElementById('External_FlightFareSearch_DepartureDate4').style.border = '';
    document.getElementById('External_FlightFareSearch_ReturnDate4').style.border = '';
	
	document.getElementById('External_FlightFareSearch_From').style.border = '';
    document.getElementById('External_FlightFareSearch_To').style.border = '';
	
	document.getElementById('External_FlightFareSearch_From0').style.border = '';
    document.getElementById('External_FlightFareSearch_To0').style.border = '';
	
	document.getElementById('External_FlightFareSearch_From1').style.border = '';
    document.getElementById('External_FlightFareSearch_To1').style.border = '';
	
	document.getElementById('External_FlightFareSearch_From2').style.border = '';
    document.getElementById('External_FlightFareSearch_To2').style.border = '';
	
    document.getElementById('External_FlightFareSearch_From3').style.border = '';
    document.getElementById('External_FlightFareSearch_To3').style.border = '';
	
	document.getElementById('External_FlightFareSearch_From4').style.border = '';
    document.getElementById('External_FlightFareSearch_To4').style.border = '';
    
  
  
   if (tempcode1 == "") {
        alert("You must select Origin");
        document.getElementById('External_FlightFareSearch_From').style.border = '1px solid red';
        document.getElementById('External_FlightFareSearch_From').focus();
        return false;
    }
    else if (tempcode == "") {
        alert("You must select Destination");
        document.getElementById('External_FlightFareSearch_To').style.border = '1px solid red';
        document.getElementById('External_FlightFareSearch_To').focus();

        return false;

    }

    else if (tempcode1 == tempcode) {
        alert("Destination should be different City");
        document.getElementById('External_FlightFareSearch_To').style.border = '1px solid red';
        document.getElementById('External_FlightFareSearch_From').style.border = '1px solid red';
        document.getElementById('External_FlightFareSearch_To').focus();

        return false;
    }
    else if (dptdate == "") {
        alert("You must select Travel Date");
        document.getElementById('External_FlightFareSearch_DepartureDate').style.border = '1px solid red';
        return false;
    }
    /*else if (rtndate == "" && document.getElementById('onewaystatus').value == "return") {
        alert("You must select Return Date");
        document.getElementById('External_FlightFareSearch_ReturnDate').style.border = '1px solid red';
        return false;
    }*/
   
  
    else {

        
        return true;
    }













}




