<?php
$mysql_hostname = 'db619120152.db.1and1.com';
$mysql_user = 'db619120152';
$mysql_database = 'db619120152';
$mysql_password ='fadymichelsmart21218585';

$mysqli = new mysqli($mysql_hostname,$mysql_user, $mysql_password, $mysql_database);
$q = "select id, value, cyti from airepostliste";
$sql = $mysqli->query($q);
$data = array();
while($row = mysqli_fetch_array($sql, true)){
    $data[] = $row; 
};
echo json_encode($data);
?>
